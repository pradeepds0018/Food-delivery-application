### Food delivery app

### Show some :heart: and star the repo to support the project

<a href="https://www.linkedin.com/in/ashwin-bicholiya-9938481a0/">
  <img align="left" alt="Ashwin's Linkdein" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg" />
</a>[Linkedin]
<br/>

### Check Other Flutter Project
SCANPAY Self Checkout App 
https://github.com/Ashwinbicholiya/scanpay

### Apk
https://drive.google.com/file/d/17dFLghpxs5x_lWXH_xyEmrzMMi4FT_8E/view?usp=drivesdk

### Some Screenshots

![1](https://user-images.githubusercontent.com/47949413/93661921-4d1db200-fa79-11ea-8ebf-4ce3246ecf1e.JPG)
![2](https://user-images.githubusercontent.com/47949413/93661926-5575ed00-fa79-11ea-9d37-463b4918a921.JPG)	


### License
    MIT License

    Copyright (c) 2020 ashwin bicholiya

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.

## Getting Started
For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
<br/>
For help on editing plugin code, view the [documentation](https://flutter.io/platform-plugins/#edit-code).
