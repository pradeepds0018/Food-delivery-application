import 'dart:ui';

class Themes {
  static final Color color = Color(0xfffeb324);
}
